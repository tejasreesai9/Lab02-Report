package com.hbase;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class HbaseStart
{
	static public void main(String args[]) throws IOException {
		
		createTable();
		insertTable();
	//	retrieveTable();
	//	deleteTable();
	//	getAllRow();
	//	getAllTable();
		}
	
	
	public static void createTable() throws IOException
	{
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
		
		HBaseAdmin admin = new HBaseAdmin(config);
		
		try {
			// HBaseConfiguration hc = new HBaseConfiguration(new Configuration());
			
			  HTableDescriptor ht = new HTableDescriptor("Group7SensorTable"); 
			  
			  ht.addFamily( new HColumnDescriptor("Humidity"));

		  ht.addFamily( new HColumnDescriptor("Temperature"));
			  
			  ht.addFamily( new HColumnDescriptor("Date"));
			  
			  ht.addFamily( new HColumnDescriptor("Accelerometer"));
			  
			  ht.addFamily( new HColumnDescriptor("Gyroscope"));
			  
		//	  ht.addFamily( new HColumnDescriptor("z"));
			  
			  System.out.println( "connecting" );

			  HBaseAdmin hba = new HBaseAdmin( config );

			  System.out.println( "Creating Table" );

			  hba.createTable( ht );

			  System.out.println("Done......");
			  
			  	
        } finally {
            admin.close();
        }
		
		
	}
	
	
	public static void insertTable() throws IOException{
	
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
         
         
         
         

		  HTable table = new HTable(config, "Group7SensorTable");
	
		  //Put p = new Put(Bytes.toBytes("row1"));
		  
		  int count=1;
		  int timestamp=10000;
         
        BufferedReader br = null;
         
 		try {
  
 			String sCurrentLine;
  
 			br = new BufferedReader(new FileReader("sensor.txt"));
  
 			while ((sCurrentLine = br.readLine()) != null) {
 				
 				/*
 				 while ((sCurrentLine = br.readLine()) != null) {
 				
 				 Put p = new Put(Bytes.toBytes("row1"),timestamp);
 				
 				if(sCurrentLine.equals(""))
 				{
 					continue;
 				}
 				System.out.println("\nCurrent Line :" + sCurrentLine);
 				String[] array = sCurrentLine.split("\t");
 				String delim="#";
 				int check=0;
 				while(array[check].contains("*")==false)
 				{
 					System.out.println("\nInside while :" + array[check]+"\t" +check);
 					String[] words=array[check].split(delim);
 					if (words[0].contains("Latitude"))
 						latitude = words[1];
 					if (words[0].contains("Longitude"))
 						longitude=words[1];
 					if (words[0].contains("Date"))
 						Date=words[1];
 					if (words[0].contains("X"))
 						x=words[1];
 					if (words[0].contains("Y"))
 						y=words[1];
 					if (words[0].contains("Z"))
 						z=words[1];
 					if (words[0].contains("Humidity"))
 						humid = words[1];
 					if (words[0].contains("Hum Ambient temperature"))
 						temp=words[1];
 					check++;
 					System.out.println("Date : "+Date);
 					System.out.println("Latitude : "+latitude);
 					System.out.println("Longitude : "+longitude);
 				//	System.out.println("Date : "+x);
 				
 				}
 				
 				if (latitude!="" || longitude!="")
 				{
 					p.add(Bytes.toBytes("Location"), Bytes.toBytes("col"+count),Bytes.toBytes(latitude));
 					p.add(Bytes.toBytes("Location"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
 					System.out.println(" Inside if condition Latitude : "+latitude);
 				} 
 				// p.add(Bytes.toBytes("longitude"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
 				if (Date!="")
 				 p.add(Bytes.toBytes("Date"), Bytes.toBytes("col"+(count+2)),Bytes.toBytes(Date));
 				//if (x!="" || y!="" || z!="")
 				 p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+3)),Bytes.toBytes(x));
 				p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
 				p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
 				 if (humid !="")
 					 p.add(Bytes.toBytes("Humidity"), Bytes.toBytes("col"+(count+6)),Bytes.toBytes(humid));
 				 if (temp!="")
 					 p.add(Bytes.toBytes("Temperature"), Bytes.toBytes("col"+(count+7)),Bytes.toBytes(temp));
 			//	p.add(Bytes.toBytes("y"), Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
 				
 			//	p.add(Bytes.toBytes("z"), Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
 				 
 			      table.put(p);
 			     // check++;
 			      count=count+8;
 			      timestamp=timestamp+1;
 				
 			}
 				 */
 				
 				
 				String Amb_temp="",obj_temp="",Date="",acc_x="",acc_y="",acc_z="",gyr_x="",gyr_y="",gyr_z="",rel_humid="";
 				if(sCurrentLine.equals(""))
 				{
 					continue;
 				}
 				
 				String[] array = sCurrentLine.split(",");
 				int check=0;
 				 Put p = new Put(Bytes.toBytes("row1"),timestamp);
 			//	latitude = array[0];
 			//	longitude=array[1];
 				//while(array[check].contains("\n")==false)
 			//	{
 					System.out.println("\nInside while :" + array[check]+"\t" +check);
 					//String[] words=array[check].split(delim);
 					if (array[check].contains("CDT"))
 						Date=array[check];
 					if (array[check+1].contains("Ambient Temperature"))
 						Amb_temp=array[check+1];
 					if (array[check+1].contains("Object Temperature"))
 						obj_temp=array[check+1];
 					if (array[check+1].contains("Relative Humidity"))
 						rel_humid=array[check+1];
 					if (array[check+1].contains("Acceleration"))
 					{
 						String[] acc = array[check+1].split(":");
 						acc_x=acc[3];
 						acc_y=array[check+2];
 						acc_z=array[check+3];
 					}
 					if (array[check+1].contains("Orientation"))
 					{
 						String[] gyr = array[check+1].split(":");
 						gyr_x=gyr[3];
 						gyr_y=array[check+2];
 						gyr_z=array[check+3];
 					}
 					check++;
 					System.out.println("Date : "+Date);
 					System.out.println("Accelerometer: "+acc_x);
 					System.out.println("Gyroscope: "+gyr_x);
 				//	System.out.println("Date : "+x);
 				
 			//	}
 				
 			//	if (Date!="")
 			//	{
 					p.add(Bytes.toBytes("Date"), Bytes.toBytes("col"+count),Bytes.toBytes(Date));
 				//	p.add(Bytes.toBytes("Location"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
 				//	System.out.println(" Inside if condition Latitude : "+latitude);
 				//} 
 				// p.add(Bytes.toBytes("longitude"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
 			//	if (Amb_temp!=""||obj_temp!="")
 					p.add(Bytes.toBytes("Temperature"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(Amb_temp+","+obj_temp));
 				//if (x!="" || y!="" || z!="")
 				p.add(Bytes.toBytes("Accelerometer"), Bytes.toBytes("col"+(count+3)),Bytes.toBytes(acc_x+","+acc_y+","+acc_z));
 				p.add(Bytes.toBytes("Gyroscope"), Bytes.toBytes("col"+(count+6)),Bytes.toBytes(gyr_x+","+gyr_y+","+gyr_z));
 				p.add(Bytes.toBytes("Humidity"), Bytes.toBytes("col"+(count+10)),Bytes.toBytes(rel_humid));
 				
 				
 			      table.put(p);
 			     // check++;
 			      count=count+11;
 			      timestamp=timestamp+1;
 				
 			}
  
 		} catch (IOException e) {
 			e.printStackTrace();
 		} finally {
 			try {
 				if (br != null)br.close();
 			} catch (IOException ex) {
 				ex.printStackTrace();
 			}
 		}
         
         
		
		
	  
	    
	}
	
	
	public static void retrieveTable() throws IOException{
		
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
		
		
		  HTable table = new HTable(config, "Group7SensorTable");
		
		 Get g = new Get(Bytes.toBytes("row1"));

		  Result r = table.get(g);

		  byte [] value = r.getValue(Bytes.toBytes("latitude"),Bytes.toBytes("col1"));

		  byte [] value1 = r.getValue(Bytes.toBytes("longitude"),Bytes.toBytes("col2"));

		  byte [] value2 = r.getValue(Bytes.toBytes("Date"),Bytes.toBytes("col3"));
		  
		  byte [] value3 = r.getValue(Bytes.toBytes("x"),Bytes.toBytes("col4"));
		  
		  byte [] value4 = r.getValue(Bytes.toBytes("y"),Bytes.toBytes("col5"));
		  
		  byte [] value5 = r.getValue(Bytes.toBytes("z"),Bytes.toBytes("col6"));
		  
		  String valueStr = Bytes.toString(value);

		  String valueStr1 = Bytes.toString(value1);
		  
		  String valueStr2 = Bytes.toString(value2);
		  
		  String valueStr3 = Bytes.toString(value3);
		  
		  String valueStr4 = Bytes.toString(value4);
		  
		  String valueStr5 = Bytes.toString(value5);

		  System.out.println("GET: " +"latitude: "+ valueStr+"longitude: "+valueStr1);
		  System.out.println("GET: " +"Date: "+ valueStr2);
		  System.out.println("GET: " +"x: "+ valueStr3);
		  System.out.println("GET: " +"y: "+ valueStr4);
		  System.out.println("GET: " +"z: "+ valueStr5);

		  

		  Scan s = new Scan();

		  s.addColumn(Bytes.toBytes("latitude"), Bytes.toBytes("col1"));

		  s.addColumn(Bytes.toBytes("longitude"), Bytes.toBytes("col2"));

		  ResultScanner scanner = table.getScanner(s);

		  try
		  {
		   for (Result rr = scanner.next(); rr != null; rr = scanner.next())
		   {
		    System.out.println("Found row : " + rr);
		   }
		  } finally
		  {
		   // Make sure you close your scanners when you are done!
		   scanner.close();
		  }
		
	}
	
	
	public static void deleteTable() throws IOException{
		
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
         
         HBaseAdmin admin = new HBaseAdmin(config);
         admin.disableTable("Group7SensorTable");
         admin.deleteTable("Group7SensorTable");

	}
	
	public static void getAllRow() throws IOException
	{
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
         
         HTable table = new HTable(config, "Group7SensorTable");
         Get g = new Get(Bytes.toBytes("row1"));

		  Result r = table.get(g);
         for(KeyValue kv : r.raw()){
             System.out.print(new String(kv.getRow()) + " " );
             System.out.print(new String(kv.getFamily()) + ":" );
             System.out.print(new String(kv.getQualifier()) + " " );
             System.out.print(kv.getTimestamp() + " " );
             System.out.println(new String(kv.getValue()));
         }
         
   /*      for(KeyValue kv : r.raw()){
        	 
        	 String familyname = new String(kv.getFamily());
            
        	 if(familyname.equals("Accelerometer"))
        	 {
        		 System.out.println("=============="+familyname+"==============");
        		 System.out.print(new String(kv.getQualifier())+":");
        		 System.out.println(new String(kv.getValue()));
        	 }
        	 
         }*/
	}
	
	public static void getAllTable() throws IOException
	{
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.127");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.127:60010");
		
		try{
            HTable table = new HTable(config, "SensorTagTable");
            Scan s = new Scan();
            ResultScanner ss = table.getScanner(s);
            for(Result r:ss){
                for(KeyValue kv : r.raw()){
                   System.out.print(new String(kv.getRow()) + " ");
                   System.out.print(new String(kv.getFamily()) + ":");
                   System.out.print(new String(kv.getQualifier()) + " ");
                   System.out.print(kv.getTimestamp() + " ");
                   System.out.println(new String(kv.getValue()));
                }
            }
       } catch (IOException e){
           e.printStackTrace();
       }
		
	}
}

